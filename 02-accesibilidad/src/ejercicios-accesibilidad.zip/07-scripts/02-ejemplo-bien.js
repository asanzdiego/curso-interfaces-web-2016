window.onload = function() {

  var link = document.querySelector("a");
  
  link.onclick = function() {
  
    alert("Hola Mundo");
  }
}